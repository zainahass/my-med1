
import React, { useMemo } from 'react';
import { SparklesIcon } from './icons';
import { UserProfile } from '../types';

interface HealthTipBannerProps {
  userProfile: UserProfile;
}

const HealthTipBanner: React.FC<HealthTipBannerProps> = ({ userProfile }) => {
  const conditions = userProfile.chronicConditions || [];

  if (conditions.length === 0) return null;

  // Database of tips
  const tipsDB: Record<string, string[]> = {
    'hypertension': [
        'قلل من استهلاك الصوديوم (الملح) في طعامك للحفاظ على ضغط الدم في المعدل الطبيعي.',
        'ممارسة المشي السريع لمدة 30 دقيقة يومياً تساعد بشكل كبير في خفض ضغط الدم.',
        'تجنب التوتر والقلق قدر الإمكان، فالحالة النفسية تؤثر مباشرة على ضغط الدم.',
        'أكثر من تناول الخضروات والفواكه الغنية بالبوتاسيوم مثل الموز والبطاطا.',
        'التزم بمواعيد أدوية الضغط ولا تتوقف عنها فجأة دون استشارة الطبيب.'
    ],
    'diabetes': [
        'فحص قدميك يومياً بحثاً عن أي جروح أو تغيرات هو عادة ضرورية لمريض السكري.',
        'حافظ على انتظام وجباتك ولا تفوت وجبة الإفطار لتجنب هبوط السكر.',
        'شرب الماء بكثرة يساعد الكلى على التخلص من السكر الزائد عبر البول.',
        'النشاط البدني يزيد من حساسية الأنسولين ويساعد في ضبط مستوى السكر.',
        'احمل معك دائماً مصدراً للسكر السريع (مثل التمر أو العصير) تحسباً لأي هبوط مفاجئ.'
    ],
    'cholesterol': [
        'استبدل الدهون المشبعة (الزبدة، اللحوم الدهنية) بزيوت صحية مثل زيت الزيتون.',
        'تناول الشوفان والتفاح يومياً، فالألياف الذائبة تساعد في خفض الكوليسترول الضار.',
        'ممارسة الرياضة ترفع مستوى الكوليسترول النافع (HDL) في الدم.',
        'تجنب الأطعمة المقلية والوجبات السريعة فهي المصدر الرئيسي للدهون المتحولة.',
        'المكسرات النيئة بكميات معتدلة مفيدة لصحة القلب والشرايين.'
    ],
    'heart_failure': [
        'راقب وزنك يومياً في نفس الوقت، فأي زيادة مفاجئة قد تعني احتباس السوائل.',
        'قلل من الملح والسوائل حسب تعليمات طبيبك لتخفيف العبء على عضلة القلب.',
        'خذ قسطاً كافياً من الراحة بعد أي مجهود، ولا ترهق نفسك.',
        'التزم بأدوية مدرات البول في مواعيدها لتجنب تجمع السوائل في الرئتين.',
        'راجع الطبيب فوراً إذا شعرت بزيادة في ضيق التنفس أثناء النوم.'
    ],
    'kidney_disease': [
        'التحكم في ضغط الدم ومستوى السكر هو خط الدفاع الأول للحفاظ على سلامة كليتيك.',
        'تجنب الإفراط في تناول المسكنات (مثل الإيبوبروفين) لأنها قد تضر بوظائف الكلى.',
        'قلل من تناول الملح (الصوديوم) للحفاظ على توازن السوائل وضغط الدم.',
        'اشرب كميات كافية من الماء ما لم ينصحك الطبيب بتحديد كمية السوائل.',
        'احرص على إجراء فحوصات دورية لوظائف الكلى للاكتشاف المبكر لأي تغيرات.'
    ],
    'liver_disease': [
        'تجنب تناول الأدوية والمكملات العشبية دون استشارة الطبيب، فالكبد هو المسؤول عن تصفيتها.',
        'حافظ على وزن صحي، فالسمنة قد تؤدي إلى تراكم الدهون على الكبد (الكبد الدهني).',
        'قلل من تناول الدهون المشبعة والسكريات المكررة لتخفيف العبء على الكبد.',
        'احرص على غسل الخضروات والفواكه جيداً لتقليل التعرض للسموم والمبيدات.',
        'غسل اليدين جيداً وتجنب مشاركة الأدوات الشخصية يحميك من فيروسات الكبد.'
    ],
    'epilepsy': [
        'الانتظام الدقيق في مواعيد الدواء هو الحجر الأساس للسيطرة على النوبات.',
        'احرص على النوم الكافي والمنتظم، قلة النوم من أهم محفزات النوبات.',
        'تجنب الأضواء الوامضة القوية وألعاب الفيديو السريعة إذا كانت تحفز لديك النوبات.',
        'أخبر المقربين منك بكيفية التصرف الصحيح في حال حدوث نوبة (عدم التثبيت، وضعية الأمان).',
        'تجنب التوتر والإجهاد الشديد، وحافظ على هدوئك النفسي.'
    ],
    'parkinson': [
        'مارس تمارين التوازن والمرونة يومياً لتقليل خطر السقوط.',
        'تناول أدويتك في مواعيد دقيقة جداً (بالدقائق) لتحسين الحركة طوال اليوم.',
        'تناول الأطعمة الغنية بالألياف وشرب الماء لتجنب الإمساك الشائع مع الباركنسون.',
        'استخدم أدوات مساعدة (مثل المقابض في الحمام) لتعزيز استقلاليتك وأمانك.',
        'قسّم وجباتك إلى وجبات صغيرة وسهلة المضغ لتسهيل عملية البلع.'
    ],
    'cancer': [
        'تذكر دائماً: الشجاعة ليست غياب الخوف، بل هي الانتصار عليه. أنت أقوى مما تظن.',
        'الأمل قوة علاجية بحد ذاتها. تشير الإحصائيات لارتفاع نسب الشفاء العالمية بشكل مستمر.',
        'كل يوم جديد هو انتصار صغير. ركز على "اليوم" ودع المستقبل يأتي بوقته.',
        'جسدك يسمع ما يقوله عقلك، حدث نفسك بإيجابية وقوة.',
        'الدعم النفسي لا يقل أهمية عن العلاج الدوائي، أحط نفسك بمن تحب.',
        'إحصائية ملهمة: نسب النجاة من السرطان تضاعفت في العقود الأربعة الماضية. العلم يتقدم بسرعة.',
        'في كل رحلة علاج، هناك أيام صعبة وأيام أفضل. الأيام الأفضل قادمة لا محالة.',
        'غذائك هو جزء من علاجك، ركز على الأطعمة الغنية بمضادات الأكسدة لتقوية مناعتك.',
    ]
  };

  const availableTips = useMemo(() => {
    let tips: string[] = [];
    conditions.forEach(condition => {
        if (tipsDB[condition]) {
            tips = [...tips, ...tipsDB[condition]];
        }
    });
    return tips;
  }, [conditions]);

  const tipOfTheDay = useMemo(() => {
    if (availableTips.length === 0) return null;
    const today = new Date();
    const start = new Date(today.getFullYear(), 0, 0);
    const diff = today.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    
    return availableTips[dayOfYear % availableTips.length];
  }, [availableTips]);

  if (!tipOfTheDay) return null;

  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-5 mb-6 shadow-sm relative overflow-hidden animate-fade-in group hover:shadow-md transition-shadow">
      <div className="absolute top-0 right-0 w-24 h-24 bg-blue-200 opacity-20 rounded-full -mt-10 -mr-10 blur-xl"></div>
      <div className="absolute bottom-0 left-0 w-20 h-20 bg-indigo-200 opacity-20 rounded-full -mb-8 -ml-8 blur-xl"></div>

      <div className="flex flex-row items-start gap-4 relative z-10">
        <div className="bg-white p-2 rounded-full shadow-sm border border-blue-100 text-blue-500 shrink-0">
            <SparklesIcon className="w-8 h-8" />
        </div>
        
        <div className="flex-1">
            <h3 className="font-bold text-gray-800 text-sm mb-1">
               {userProfile.name ? `رسالة يومية لـ ${userProfile.name} 💡` : 'رسالة يومية لك 💡'}
            </h3>
            <p className="text-gray-700 text-base leading-relaxed font-medium">
                "{tipOfTheDay}"
            </p>
             <div className="mt-2 flex items-center gap-1">
                <span className="h-1 w-1 bg-blue-400 rounded-full"></span>
                <span className="text-[10px] text-blue-500 font-semibold">
                    {conditions.includes('cancer') ? 'معاً أقوى ضد المرض' : 'نصيحة يومية لحالة أفضل'}
                </span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default HealthTipBanner;
