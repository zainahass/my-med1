import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'dart:math';
import '../services/notification_service.dart';
import '../services/api_service.dart';
import '../services/patient_data_sync_service.dart';

class PillTrackerResult {
  final bool doseRecorded;
  final bool needsRefillInput;
  final bool warningAtFive;
  final int? remainingPills;
  final bool trackingEnabled;

  const PillTrackerResult({
    required this.doseRecorded,
    required this.needsRefillInput,
    required this.warningAtFive,
    required this.remainingPills,
    required this.trackingEnabled,
  });
}

class MedicationProvider extends ChangeNotifier {
  static const String _storageKey = 'medications_v1';
  static const String _missedDosesKey = 'missed_doses_tracking';
  static const int _scheduleHorizonDays = 14;
  static const int _minScheduledOccurrences = 1;
  static const int _maxScheduledOccurrences = 14;

  // Each item may include an optional imagePath (local file path to a photo)
  // We also store a prefix id so we can cancel scheduled notifications when removing
  final List<Map<String, String?>> _items = [];
  
  // Track consecutive missed doses per medication (by notifPrefix)
  final Map<String, int> _consecutiveMissedDoses = {};
  
  // Track the last expected dose time per medication
  final Map<String, DateTime> _lastExpectedDoseTime = {};
  
  // Track if we've already notified for current missed doses (to avoid spam)
  final Map<String, bool> _hasNotifiedForCurrentMissed = {};
  final Random _random = Random();

  void _syncCloudInBackground() {
    unawaited(
      PatientDataSyncService()
          .syncLocalToCloudIfAuthenticated()
          .catchError((e) {
            debugPrint('[MedicationProvider] Background sync failed: $e');
          }),
    );
  }

  List<Map<String, String?>> get items => List.unmodifiable(_items);

  List<Map<String, String>> get savedDoctors {
    final uniqueDoctors = <String, Map<String, String>>{};

    for (final item in _items) {
      final doctorName = (item['doctorName'] ?? '').trim();
      if (doctorName.isEmpty) continue;

      final doctorSpecialty = (item['doctorSpecialty'] ?? '').trim();
      final uniqueKey = '${doctorName.toLowerCase()}|${doctorSpecialty.toLowerCase()}';

      uniqueDoctors.putIfAbsent(
        uniqueKey,
        () => {
          'name': doctorName,
          'specialty': doctorSpecialty,
        },
      );
    }

    final values = uniqueDoctors.values.toList()
      ..sort((a, b) => a['name']!.toLowerCase().compareTo(b['name']!.toLowerCase()));

    return values;
  }

  String _generateUniquePrefix() {
    while (true) {
      final candidate =
          '${DateTime.now().microsecondsSinceEpoch}_${_random.nextInt(1 << 20)}';
      final exists = _items.any((item) => item['notifPrefix'] == candidate);
      if (!exists) return candidate;
    }
  }

  bool _ensureUniquePrefixes() {
    bool changed = false;
    final seen = <String>{};

    for (final item in _items) {
      final prefix = item['notifPrefix'];
      final needsNew = prefix == null || prefix.isEmpty || seen.contains(prefix);
      if (needsNew) {
        item['notifPrefix'] = _generateUniquePrefix();
        changed = true;
      }
      seen.add(item['notifPrefix']!);
    }

    return changed;
  }

  int _occurrencesForInterval(int intervalHours) {
    final safeInterval = intervalHours <= 0 ? 24 : intervalHours;
    final calculated = ((_scheduleHorizonDays * 24) / safeInterval).ceil();
    if (calculated < _minScheduledOccurrences) return _minScheduledOccurrences;
    if (calculated > _maxScheduledOccurrences) return _maxScheduledOccurrences;
    return calculated;
  }

  DateTime? _calculateNextDoseFromItem(Map<String, String?> item, DateTime now) {
    final intervalHours = int.tryParse(item['intervalHours'] ?? '24') ?? 24;
    final lastTakenStr = item['lastTaken'];

    if (lastTakenStr != null && lastTakenStr.isNotEmpty) {
      final lastTaken = DateTime.tryParse(lastTakenStr);
      if (lastTaken != null) {
        var next = lastTaken.add(Duration(hours: intervalHours));
        while (!next.isAfter(now)) {
          next = next.add(Duration(hours: intervalHours));
        }
        return next;
      }
    }

    final startTime = item['startTime'];
    if (startTime == null || startTime.isEmpty) return null;

    final parts = startTime.split(':');
    if (parts.length != 2) return null;

    final h = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    if (h == null || m == null) return null;

    DateTime base = DateTime(now.year, now.month, now.day);
    final startDate = item['startDate'];
    if (startDate != null && startDate.isNotEmpty) {
      final parsedBase = DateTime.tryParse(startDate);
      if (parsedBase != null) {
        base = DateTime(parsedBase.year, parsedBase.month, parsedBase.day);
      }
    }

    var next = DateTime(base.year, base.month, base.day, h, m);
    while (!next.isAfter(now)) {
      next = next.add(Duration(hours: intervalHours));
    }
    return next;
  }

  Future<void> _restoreMedicationSchedules() async {
    await NotificationService().resetTrackedMedicationSchedules();

    final schedulableItems = _items.where((item) {
      final prefix = item['notifPrefix'];
      final name = item['name'];
      final dose = item['dose'];
      return prefix != null && prefix.isNotEmpty && name != null && dose != null;
    }).toList();

    final perMedicationBudget = schedulableItems.isEmpty
        ? 0
        : max(
            1,
            NotificationService.recurringMedicationAlarmBudget ~/
                schedulableItems.length,
          );

    final now = DateTime.now();
    for (final item in schedulableItems) {
      final prefix = item['notifPrefix'];
      final name = item['name'];
      final dose = item['dose'];
      if (prefix == null || name == null || dose == null) continue;

      final intervalHours = int.tryParse(item['intervalHours'] ?? '24') ?? 24;
      final firstOccurrence = _calculateNextDoseFromItem(item, now);
      if (firstOccurrence == null) continue;

      try {
        await NotificationService().scheduleRepeatedOccurrences(
          prefix: prefix,
          title: 'موعد تناول $name',
          body: '$dose · كل $intervalHours ساعة',
          firstOccurrence: firstOccurrence,
          intervalHours: intervalHours,
          occurrences: min(_occurrencesForInterval(intervalHours), perMedicationBudget),
        );
      } catch (e) {
        debugPrint('[MedicationProvider] Failed to restore schedule for $name: $e');
      }
    }
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);

    if (raw == null || raw.isEmpty) {
      _items.clear();
      _consecutiveMissedDoses.clear();
      _lastExpectedDoseTime.clear();
      _hasNotifiedForCurrentMissed.clear();
      notifyListeners();
      return;
    }

    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        _items
          ..clear()
          ..addAll(
            decoded.whereType<Map>().map((entry) {
              final map = entry.map(
                (key, value) => MapEntry(key.toString(), value?.toString()),
              );

              map.putIfAbsent(
                'notifPrefix',
                () => DateTime.now().microsecondsSinceEpoch.toString(),
              );

              return Map<String, String?>.from(map);
            }),
          );
      }
    } catch (e) {
      debugPrint('[MedicationProvider.load] Failed to parse saved medications: $e');
      _items.clear();
      _consecutiveMissedDoses.clear();
      _lastExpectedDoseTime.clear();
      _hasNotifiedForCurrentMissed.clear();
    }

    final prefixesFixed = _ensureUniquePrefixes();
    if (prefixesFixed) {
      await _saveToPrefs();
    }
    
    // Load missed doses tracking data
    final missedDosesRaw = prefs.getString(_missedDosesKey);
    if (missedDosesRaw != null && missedDosesRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(missedDosesRaw) as Map<String, dynamic>;
        _consecutiveMissedDoses.clear();
        decoded.forEach((key, value) {
          if (value is int) {
            _consecutiveMissedDoses[key] = value;
          }
        });
      } catch (e) {
        debugPrint('[MedicationProvider.load] Failed to load missed doses tracking: $e');
      }
    }

    await _restoreMedicationSchedules();

    notifyListeners();
  }

  Future<void> _saveToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final payload = _items.map((item) => Map<String, String?>.from(item)).toList();
    await prefs.setString(_storageKey, jsonEncode(payload));
    _syncCloudInBackground();
  }
  
  Future<void> _saveMissedDosesTracking() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_missedDosesKey, jsonEncode(_consecutiveMissedDoses));
    _syncCloudInBackground();
  }

  Future<void> add(
    String name,
    String dose, {
    String? imagePath,
    int intervalHours = 24,
    String? startTime,
    String? startDate,
    String? chronicDisease,
    String? doctorName,
    String? doctorSpecialty,
    int? pillCount,
    int? warningBarrier,
  }) async {
    final prefix = _generateUniquePrefix();
    final barrier = warningBarrier ?? 5;
    debugPrint('[MedicationProvider.add] Adding medication: $name, dose: $dose, interval: $intervalHours hours, startTime: $startTime, startDate: $startDate, chronicDisease: $chronicDisease, warningBarrier: $barrier');

    _items.add({
      'name': name,
      'dose': dose,
      'imagePath': imagePath,
      'intervalHours': intervalHours.toString(),
      'startTime': startTime,
      'startDate': startDate,
      'chronicDisease': chronicDisease,
      'doctorName': doctorName,
      'doctorSpecialty': doctorSpecialty,
      'pillCountRemaining': pillCount?.toString(),
      'warningBarrier': barrier.toString(),
      'lowPillWarningSent': (pillCount != null && pillCount <= barrier) ? 'true' : 'false',
      'refillRequired': (pillCount != null && pillCount <= 0) ? 'true' : 'false',
      'notifPrefix': prefix,
    });

    await _saveToPrefs();

    // Schedule notifications based on startTime, optional startDate and intervalHours
    try {
      if (startTime != null) {
        final parts = startTime.split(':');
        if (parts.length == 2) {
          final h = int.tryParse(parts[0]);
          final m = int.tryParse(parts[1]);
          if (h != null && m != null) {
            DateTime now = DateTime.now();
            debugPrint('[MedicationProvider.add] Parsing time: $h:$m, now=$now');

            DateTime scheduled = DateTime(now.year, now.month, now.day, h, m);
            
            if (startDate != null) {
              try {
                final base = DateTime.parse(startDate);
                scheduled = DateTime(base.year, base.month, base.day, h, m);
                debugPrint('[MedicationProvider.add] Using provided date: $startDate, scheduled: $scheduled');
              } catch (e) {
                debugPrint('[MedicationProvider.add] Failed to parse date, using today: $scheduled, error: $e');
              }
            }

            DateTime firstDue = scheduled;
            // Push forward until it is in the future
            // If the scheduled time is in the past, add interval hours repeatedly until we reach a future time
            while (!firstDue.isAfter(now)) {
              firstDue = firstDue.add(Duration(hours: intervalHours));
              debugPrint('[MedicationProvider.add] Past time detected, advancing to next interval: $firstDue');
            }
            debugPrint('[MedicationProvider.add] First due time: $firstDue, now: $now, diff: ${firstDue.difference(now).inMinutes} minutes');

            // schedule next 30 occurrences starting at the next due time
            debugPrint('[MedicationProvider.add] About to schedule ${intervalHours}h recurring notifications starting at $firstDue');
            await NotificationService().scheduleRepeatedOccurrences(
              prefix: prefix,
              title: 'موعد تناول $name',
              body: '$dose · كل $intervalHours ساعة',
              firstOccurrence: firstDue,
              intervalHours: intervalHours,
              occurrences: _occurrencesForInterval(intervalHours),
            );
            debugPrint('[MedicationProvider.add] Successfully scheduled notifications for prefix: $prefix');
          } else {
            debugPrint('[MedicationProvider.add] Failed to parse hours/minutes from $startTime');
          }
        } else {
          debugPrint('[MedicationProvider.add] Invalid time format: $startTime');
        }
      } else {
        debugPrint('[MedicationProvider.add] No startTime provided, skipping notification scheduling');
      }
    } catch (e, st) {
      debugPrint('[MedicationProvider.add] ERROR scheduling notifications: $e\n$st');
    }

    notifyListeners();
  }

  Future<PillTrackerResult> recordTaken(String prefix) async {
    // Find medication
    final idx = _items.indexWhere((it) => it['notifPrefix'] == prefix);
    if (idx == -1) {
      return const PillTrackerResult(
        doseRecorded: false,
        needsRefillInput: false,
        warningAtFive: false,
        remainingPills: null,
        trackingEnabled: false,
      );
    }

    final item = _items[idx];
    final intervalStr = item['intervalHours'];
    final interval = int.tryParse(intervalStr ?? '24') ?? 24;
    final currentPillCount = int.tryParse(item['pillCountRemaining'] ?? '');
    final warningBarrier = int.tryParse(item['warningBarrier'] ?? '5') ?? 5;
    final trackingEnabled = true;

    if (currentPillCount == null) {
      item['refillRequired'] = 'true';
      await _saveToPrefs();
      notifyListeners();

      return const PillTrackerResult(
        doseRecorded: false,
        needsRefillInput: true,
        warningAtFive: false,
        remainingPills: null,
        trackingEnabled: true,
      );
    }

    if (trackingEnabled && currentPillCount <= 0) {
      item['refillRequired'] = 'true';
      await _saveToPrefs();
      notifyListeners();

      return const PillTrackerResult(
        doseRecorded: false,
        needsRefillInput: true,
        warningAtFive: false,
        remainingPills: 0,
        trackingEnabled: true,
      );
    }

    // Cancel existing scheduled notifs and reschedule starting from now+interval
    await NotificationService().cancelForPrefix(prefix);
    final now = DateTime.now();
    final first = now.add(Duration(hours: interval));
    await NotificationService().scheduleRepeatedOccurrences(
      prefix: prefix,
      title: 'موعد تناول ${item['name']}',
      body: '${item['dose']} · كل $interval ساعة',
      firstOccurrence: first,
      intervalHours: interval,
      occurrences: _occurrencesForInterval(interval),
    );

    // Save lastTaken timestamp for UI if desired
    item['lastTaken'] = now.toIso8601String();

    var warningAtBarrier = false;
    var remainingPills = currentPillCount;

    if (trackingEnabled && currentPillCount > 0) {
      remainingPills = max(0, currentPillCount - 1);
      item['pillCountRemaining'] = remainingPills.toString();

      final alreadyWarnedAtBarrier = item['lowPillWarningSent'] == 'true';
      if (remainingPills == warningBarrier && !alreadyWarnedAtBarrier) {
        warningAtBarrier = true;
        item['lowPillWarningSent'] = 'true';
      }

      if (remainingPills > warningBarrier) {
        item['lowPillWarningSent'] = 'false';
      }

      item['refillRequired'] = remainingPills == 0 ? 'true' : 'false';
    }
    
    // Reset consecutive missed doses counter when dose is taken
    _consecutiveMissedDoses[prefix] = 0;
    _hasNotifiedForCurrentMissed[prefix] = false;
    _lastExpectedDoseTime[prefix] = first;
    
    await _saveToPrefs();
    await _saveMissedDosesTracking();

    notifyListeners();

    return PillTrackerResult(
      doseRecorded: true,
      needsRefillInput: trackingEnabled && remainingPills == 0,
      warningAtFive: warningAtBarrier,
      remainingPills: remainingPills,
      trackingEnabled: trackingEnabled,
    );
  }

  Future<void> refillPills(String prefix, int newPillCount) async {
    final idx = _items.indexWhere((it) => it['notifPrefix'] == prefix);
    if (idx == -1) return;

    final safeCount = max(0, newPillCount);
    final item = _items[idx];

    item['pillCountRemaining'] = safeCount.toString();
    item['refillRequired'] = safeCount == 0 ? 'true' : 'false';
    item['lowPillWarningSent'] = safeCount <= 5 ? 'true' : 'false';

    await _saveToPrefs();
    notifyListeners();
  }

  Future<void> removeAt(int index) async {
    if (index < 0 || index >= _items.length) return;

    final item = _items[index];
    final prefix = item['notifPrefix'];
    if (prefix != null) {
      await NotificationService().cancelForPrefix(prefix);
    }

    _items.removeAt(index);
    await _saveToPrefs();
    notifyListeners();
  }

  Future<void> updateAt(
    int index,
    String name,
    String dose, {
    String? imagePath,
    int intervalHours = 24,
    String? startTime,
    String? startDate,
    String? chronicDisease,
    String? doctorName,
    String? doctorSpecialty,
    int? pillCount,
    int? warningBarrier,
  }) async {
    if (index < 0 || index >= _items.length) return;

    final existing = _items[index];
    final String prefix = (existing['notifPrefix'] == null || existing['notifPrefix']!.isEmpty)
        ? _generateUniquePrefix()
        : existing['notifPrefix']!;

    final previousInterval = int.tryParse(existing['intervalHours'] ?? '24') ?? 24;
    final previousStartTime = existing['startTime'] ?? '';
    final previousStartDate = existing['startDate'] ?? '';

    final normalizedStartTime = startTime ?? '';
    final normalizedStartDate = startDate ?? '';

    final timingChanged =
        previousInterval != intervalHours ||
        previousStartTime != normalizedStartTime ||
        previousStartDate != normalizedStartDate;

    final barrier = warningBarrier ?? (int.tryParse(existing['warningBarrier'] ?? '5') ?? 5);

    _items[index] = {
      'name': name,
      'dose': dose,
      'imagePath': imagePath,
      'intervalHours': intervalHours.toString(),
      'startTime': startTime,
      'startDate': startDate,
      'chronicDisease': chronicDisease,
      'doctorName': doctorName,
      'doctorSpecialty': doctorSpecialty,
      'pillCountRemaining': pillCount?.toString() ?? existing['pillCountRemaining'],
      'warningBarrier': barrier.toString(),
      'lowPillWarningSent': pillCount == null
        ? (existing['lowPillWarningSent'] ?? 'false')
        : (pillCount <= barrier ? 'true' : 'false'),
      'refillRequired': pillCount == null
        ? (existing['refillRequired'] ?? 'false')
        : (pillCount <= 0 ? 'true' : 'false'),
      'notifPrefix': prefix,
      'lastTaken': timingChanged ? null : existing['lastTaken'],
    };

    await _saveToPrefs();

    if (timingChanged) {
      _consecutiveMissedDoses[prefix] = 0;
      _hasNotifiedForCurrentMissed[prefix] = false;
      _lastExpectedDoseTime.remove(prefix);
      await _saveMissedDosesTracking();
    }

    // Reschedule notifications only for this same medication entry.
    try {
      await NotificationService().cancelForPrefix(prefix);

      final now = DateTime.now();
      final firstDue = _calculateNextDoseFromItem(_items[index], now);

      if (firstDue != null) {
        await NotificationService().scheduleRepeatedOccurrences(
          prefix: prefix,
          title: 'موعد تناول $name',
          body: '$dose · كل $intervalHours ساعة',
          firstOccurrence: firstDue,
          intervalHours: intervalHours,
          occurrences: _occurrencesForInterval(intervalHours),
        );
      }
    } catch (e) {
      debugPrint('[MedicationProvider.updateAt] Failed to reschedule $name: $e');
    }

    notifyListeners();
  }
  
  /// Check all medications for missed doses and notify caregiver if needed
  /// Returns true if any notifications were sent
  Future<bool> checkForMissedDoses(String? patientUsername) async {
    if (patientUsername == null || patientUsername.isEmpty) {
      debugPrint('[MedicationProvider] No patient username, skipping missed dose check');
      return false;
    }
    
    bool anyNotificationsSent = false;
    final now = DateTime.now();
    
    for (final item in _items) {
      final prefix = item['notifPrefix'];
      if (prefix == null) continue;
      
      final name = item['name'] ?? 'Unknown Medication';
      final intervalStr = item['intervalHours'];
      final interval = int.tryParse(intervalStr ?? '24') ?? 24;
      final lastTakenStr = item['lastTaken'];
      
      // Calculate expected dose time
      DateTime? expectedDoseTime;
      
      if (lastTakenStr != null) {
        // If medication was taken before, next dose is lastTaken + interval
        try {
          final lastTaken = DateTime.parse(lastTakenStr);
          expectedDoseTime = lastTaken.add(Duration(hours: interval));
        } catch (e) {
          debugPrint('[MedicationProvider] Failed to parse lastTaken: $e');
        }
      } else {
        // If never taken, calculate from startTime and startDate
        final startTime = item['startTime'];
        final startDate = item['startDate'];
        
        if (startTime != null) {
          final parts = startTime.split(':');
          if (parts.length == 2) {
            final h = int.tryParse(parts[0]);
            final m = int.tryParse(parts[1]);
            
            if (h != null && m != null) {
              DateTime baseDate = DateTime(now.year, now.month, now.day);
              
              if (startDate != null) {
                try {
                  baseDate = DateTime.parse(startDate);
                } catch (e) {
                  debugPrint('[MedicationProvider] Failed to parse startDate: $e');
                }
              }
              
              expectedDoseTime = DateTime(baseDate.year, baseDate.month, baseDate.day, h, m);
              
              // Find the next expected dose time in the past or near future
              while (expectedDoseTime!.isAfter(now)) {
                expectedDoseTime = expectedDoseTime.subtract(Duration(hours: interval));
              }
              
              // Now advance to the first dose that should have been taken
              while (expectedDoseTime!.isBefore(now.subtract(Duration(hours: interval * 2)))) {
                expectedDoseTime = expectedDoseTime.add(Duration(hours: interval));
              }
            }
          }
        }
      }
      
      if (expectedDoseTime == null) {
        debugPrint('[MedicationProvider] Could not calculate expected dose time for $name');
        continue;
      }
      
      // Check if dose was missed (allowing 1 hour grace period)
      final gracePeriod = Duration(hours: 1);
      final missedThreshold = expectedDoseTime.add(gracePeriod);
      
      if (now.isAfter(missedThreshold)) {
        // Dose was missed!
        final currentMissedCount = _consecutiveMissedDoses[prefix] ?? 0;
        
        // Calculate how many doses were missed
        final hoursSinceMissed = now.difference(expectedDoseTime).inHours;
        final dosesMissed = (hoursSinceMissed / interval).floor();
        
        if (dosesMissed > currentMissedCount) {
          // Update missed count
          _consecutiveMissedDoses[prefix] = dosesMissed;
          await _saveMissedDosesTracking();
          
          debugPrint('[MedicationProvider] $name: $dosesMissed consecutive doses missed');
          
          // Notify caregiver if 2 or more doses missed and we haven't notified yet
          if (dosesMissed >= 2 && _hasNotifiedForCurrentMissed[prefix] != true) {
            try {
              await ApiService().notifyMissedDoses(
                patientUsername: patientUsername,
                consecutiveMissed: dosesMissed,
                medicationName: name,
              );
              
              _hasNotifiedForCurrentMissed[prefix] = true;
              anyNotificationsSent = true;
              
              debugPrint('[MedicationProvider] Notified caregiver about $dosesMissed missed doses for $name');
            } catch (e) {
              debugPrint('[MedicationProvider] Failed to notify caregiver: $e');
            }
          }
        }
      } else {
        // Dose not yet missed, reset counter if it was previously set
        if (_consecutiveMissedDoses.containsKey(prefix) && _consecutiveMissedDoses[prefix]! > 0) {
          debugPrint('[MedicationProvider] Resetting missed counter for $name (dose not yet due)');
        }
      }
      
      // Store last expected dose time for reference
      _lastExpectedDoseTime[prefix] = expectedDoseTime;
    }
    
    return anyNotificationsSent;
  }
  
  /// Get the number of consecutive missed doses for a medication
  int getMissedDosesCount(String prefix) {
    return _consecutiveMissedDoses[prefix] ?? 0;
  }
  
  /// Manually trigger missed dose check (can be called from UI or on app resume)
  Future<void> performMissedDoseCheck(String? patientUsername) async {
    await checkForMissedDoses(patientUsername);
    notifyListeners();
  }
}